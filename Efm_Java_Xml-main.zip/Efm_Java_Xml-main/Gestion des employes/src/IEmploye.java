import java.util.Date;

public interface IEmploye {
    public Date age();
    public Date anciennete();
    public Date dateRetraite(int ageRetraite);
}
